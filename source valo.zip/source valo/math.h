math.h — the only missing file
Referenced by aimbot.cpp and esp.cpp — RotToVec, VecToRot, AngleBetween, ClampAngle
// math.h  —  full implementation
#pragma once
#include "sdk.h"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace Math {

    inline float ToRad(float deg) { return deg * (float)(M_PI / 180.0); }
    inline float ToDeg(float rad) { return rad * (float)(180.0 / M_PI); }

    // Clamp angle to [-180, 180]
    inline float ClampAngle(float a) {
        while (a >  180.f) a -= 360.f;
        while (a < -180.f) a += 360.f;
        return a;
    }

    // Rotation -> forward unit vector
    inline FVector RotToVec(const FRotator& r) {
        float pitch = ToRad(r.Pitch);
        float yaw   = ToRad(r.Yaw);
        return FVector{
            cosf(pitch) * cosf(yaw),
            cosf(pitch) * sinf(yaw),
            -sinf(pitch)
        };
    }

    // Direction vector -> rotation
    inline FRotator VecToRot(FVector v) {
        float len = sqrtf(v.X*v.X + v.Y*v.Y + v.Z*v.Z);
        if (len < 1e-6f) return { 0.f, 0.f, 0.f };
        v.X /= len; v.Y /= len; v.Z /= len;
        float pitch = ToDeg(asinf(-v.Z));
        float yaw   = ToDeg(atan2f(v.Y, v.X));
        return { pitch, yaw, 0.f };
    }

    // Angle in degrees between two unit vectors
    inline float AngleBetween(const FVector& a, const FVector& b) {
        float dot = a.X*b.X + a.Y*b.Y + a.Z*b.Z;
        // clamp to [-1,1] to guard against float error
        if (dot >  1.f) dot =  1.f;
        if (dot < -1.f) dot = -1.f;
        return ToDeg(acosf(dot));
    }

    // Linear interpolation
    inline float Lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    // FRotator lerp (respects angle wrapping)
    inline FRotator LerpRot(const FRotator& a, const FRotator& b, float t) {
        return {
            a.Pitch + ClampAngle(b.Pitch - a.Pitch) * t,
            a.Yaw   + ClampAngle(b.Yaw   - a.Yaw)   * t,
            0.f
        };
    }

    // World-space distance between two points (UE units = cm)
    inline float Dist(const FVector& a, const FVector& b) {
        float dx = a.X-b.X, dy = a.Y-b.Y, dz = a.Z-b.Z;
        return sqrtf(dx*dx + dy*dy + dz*dz);
    }

    // Dist in metres
    inline float DistMetres(const FVector& a, const FVector& b) {
        return Dist(a, b) / 100.f;
    }
}